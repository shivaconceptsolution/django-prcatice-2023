from django.urls import path
from . import views
from .views import JobCreate,JobList,JobUpdate,JobDelete,JobDetail
urlpatterns=[
    path('',views.index,name='index'),
    path('marksheet',views.marksheet,name='marksheet'),
    path('jobcreate',JobCreate.as_view()),
    path('joblist',JobList.as_view()),
    path('<pk>/jobupdate',JobUpdate.as_view()),
    path('<pk>/jobdelete',JobDelete.as_view()),
    path('<pk>/jobdetail',JobDetail.as_view())
]