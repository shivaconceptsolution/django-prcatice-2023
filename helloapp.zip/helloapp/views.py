from django.http import HttpResponse
from django.views.generic.edit import CreateView,UpdateView,DeleteView
from django.views.generic.detail import DetailView
from django.urls import reverse
from . models import Job
from django.views.generic.list import ListView
def index(request):
    return HttpResponse("Hello World")
def marksheet(request):
   pass

class JobCreate(CreateView):
    model = Job
    fields = ['jobtitle', 'jobdescription']
    success_url='/hello/joblist'    

class JobList(ListView):
   model = Job   # Job.objects.all()   
class JobUpdate(UpdateView):
    model = Job
    fields = ['jobtitle', 'jobdescription']
    success_url = '/hello/joblist'
class JobDelete(DeleteView):
    model = Job
    success_url = '/hello/joblist'
class JobDetail(DetailView):

  model = Job   # Job.objects.all()   